#' Generating random minimax designs for the OLS estimator
#'
#' @param n a positive integer. Sample size.
#' @param d a positive integer. Dimension.
#' @param p a real number belongs to [0,1]. Weight.
#' #'
#' @return an n-point random minimax design for the OLS estimator.
#' @export
#'
#'
#' @examples
#' ## e.g.1 An example of 20-point 2-dimensional random minimax design with p=0.5
#' n = 20
#' d = 2
#' p = 0.5
#' Xm = mMDesign_OLS(n,d,p)
#' PPlot(Xm)
mMDesign_OLS <- function(n,d,p)
{
  Qpinv<- function(p,u){
    n <- length(u)
    a <- matrix(rep(0,n),nrow = n)
    if(p==0)
    {
      a[u>=0.5] = 1
    }else{
      a = (1/p)*(u-(1-p)/2)
    }
    a[a>1] = 1
    a[a<0] = 0
    return(a)
  }
  Rpinv<- function(p,U){
    n <- nrow(U)
    d <- ncol(U)
    X <- matrix(0,nrow = n,ncol = d)
    X[,1] = Qpinv(p,U[,1])
    if(d>1){
      for(j in 2:d)
      {
        cond = matrix(rep(FALSE,n),nrow = n)
        for(i in 1:(j-1))
        {
          cond <- cond | (X[,i]*(X[,i]-1)==0)
        }
        X[cond,j] = Qpinv(0,U[cond,j])
        X[!cond,j] = Qpinv(1,U[!cond,j])
      }
    }
    return(X)
  }
  U = matrix(runif(n*d),ncol=d)
  Xm = Rpinv(p,U)
  return(Xm)
}
