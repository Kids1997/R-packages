#' MDS based on the minimax design for the OLS estimator (MDS-OLS)
#'
#' @param D_full an N*(d+1) real matrix. Full sample, the first d column
#' represents covariates and the last column represents response.
#' @param n a positive integer. Subsample size.
#' @param r a real number belong to [0,1]. The relative importance of bias to variance
#' with default value calculating from the data.
#'
#' @return n-point MDS-OLS subsamples
#' @export
#'
#'
#' @examples
#' library(scales)
#' N = 200
#' d = 2
#' n = 20
#' M2 = 1
#' sigma2 = 20
#' const = matrix(rep(1,N),ncol=1)
#' X0 = matrix(rnorm(N*d),ncol=d)
#' X <-apply(X0,2,rescale)
#' e = matrix(rnorm(N,sd=sqrt(sigma2)),ncol=1)
#' Y = const*2+X%*%matrix(c(3,3),ncol=1)+e
#' D = data.frame(X=X,Y=Y)
#' ## e.g.1 MDS-OLS subsamples with r = 0.5
#' idx_ols = MDS_OLS(D,n,0.5)
#' plot(X, main="MDS-OLS subsamples")
#' points(X[idx_ols,1:d], col="red", cex=2)
#' ## e.g.2 MDS-OLS subsamples with the default value of r
#' idx_ols = MDS_OLS(D,n)
#' plot(X, main="MDS-OLS subsamples")
#' points(X[idx_ols,1:d], col="red", cex=2)
MDS_OLS<-function(D_full,n,r=NULL)
{
  nc <- ncol(D_full)
  d <- nc-1

  if(is.null(r)){
    mE <- Estimation(D_full,20)
    sigma2 <- mE[1]
    M2 <- mE[2]
    r <- M2/(M2+sigma2/n)
  }
  p <- POPT(r,d)
  Xm <- mMDesign_OLS(n,d,p)

  idx <- NNS(D_full[,1:d],Xm)
  return(idx)
}

