#' Calculating the critical value such that the minimax design for the OLS estimator
#' has the same performance with the minimax design for the IPW estimator
#'
#' @param d a positive integer. Dimension.
#'
#' @return the critical value.
#' @export
#'
#'
#' @examples
#' rcritical(1)
#' rcritical(10)
rcritical<-function(d){
  fd<-function(x){
    return(sqrt(apply(12*(x-0.5)^2,1,sum)+1))
  }
  Ir <- function(r,d){
    f<-function(p)
    {
      y <- (1-r)*(1+d/(3-2*p))+r*(1-p)^2*(1+3*d/(3-2*p)^2)
      return(y)
    }
    if (r<= d/(2*d+9))
    {
      res = (1+d/3)*(1+r/(1-r))
    }else if(r<1)
    {
      A = optimize(f,c(0,1),tol=1e-5)
      res = A$objective/(1-r)
    }else{
      res = 1+d
    }
    return(res)
  }
  N = 1e6
  x = matrix(runif(N*d),ncol = d)
  IPW = mean(fd(x))^2

  diss<-function(r)
  {
    return((Ir(r,d)-IPW)^2)
  }
  rastar = optimize(diss,c(0,1),tol=1e-5)$minimum
  return(rastar)
}
