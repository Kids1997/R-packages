#' MDS based on the minimax design for the IPW estimator (MDS-IPW)
#'
#' @param D_full an N*(d+1) real matrix. Full sample, the first d column
#' represents covariates and the last column represents response.
#' @param n a positive integer. Subsample size.
#' @param psqrt a functional variable. psqrt(x)=sqrt{1+z(x)^Tz(x)}
#'  with the default value z(x)=(1,2sqrt{3}(x_1-1/2),cdots,2sqrt{3}(x_d-1/2)).
#' @param C a positive real number. The maximum of the function psqrt
#' with the default value calculating by MC approximation.
#'
#' @return n-point MDS-IPW subsamples
#' @export
#'
#'
#' @examples
#' library(scales)
#' N = 200
#' d = 2
#' n = 20
#' M2 = 1
#' sigma2 = 20
#' const = matrix(rep(1,N),ncol=1)
#' X0 = matrix(rnorm(N*d),ncol=d)
#' X <-apply(X0,2,rescale)
#' e = matrix(rnorm(N,sd=sqrt(sigma2)),ncol=1)
#' Y = const*2+X%*%matrix(c(3,3),ncol=1)+e
#' D = cbind(X,Y)
#' ## e.g.1 minimax design based subsample
#' idx_ipw = MDS_IPW(D,n)
#' plot(X, main="MDS-IPW subsamples")
#' points(X[idx_ipw,1:d], col="red", cex=2)
MDS_IPW<-function(D_full,n,psqrt=NULL,C=NULL)
{
  nc <- ncol(D_full)
  d <- nc-1

  Xm <- mMDesign_IPW(n,d,psqrt,C)
  idx <- NNS(D_full[,1:d],Xm)
  return(idx)
}
