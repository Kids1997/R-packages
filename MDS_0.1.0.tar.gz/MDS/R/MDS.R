#' Minimax Desing based Subsampling (MDS)
#'
#' @param D_full an N*(d+1) real matrix. Full sample, the first d column
#' represents covariates and the last column represents response.
#' @param n a positive integer. Subsample size.
#'
#' @return n-point MDS subsamples
#' @export
#'
#'
#' @examples
#' library(scales)
#' N = 200
#' d = 2
#' n = 20
#' M2 = 1
#' sigma2 = 20
#' const = matrix(rep(1,N),ncol=1)
#' X0 = matrix(rnorm(N*d),ncol=d)
#' X <-apply(X0,2,rescale)
#' e = matrix(rnorm(N,sd=sqrt(sigma2)),ncol=1)
#' Y = const*2+X%*%matrix(c(3,3),ncol=1)+e
#' D = data.frame(X=X,Y=Y)
#' ## e.g.1 minimax design based subsample
#' idx = MDS(D,n)
#' plot(X, main="MDS subsamples")
#' points(X[idx,1:d], col="red", cex=2)
MDS<-function(D_full,n)
{
  nc <- ncol(D_full)
  d <- nc-1
  r_star <- rcritical(d)
  mE <- Estimation(D_full,20)
  sigma2 <- mE[1]
  M2 <- mE[2]
  r <- M2/(M2+sigma2*(1+d)^2/n)
  if(r<r_star){
    # MDS-OLS
    idx <- MDS_OLS(D_full,n,r)
  }else{
    # MDS-IPW
    idx <- MDS_IPW(D_full,n)
  }

  return(idx)
}
