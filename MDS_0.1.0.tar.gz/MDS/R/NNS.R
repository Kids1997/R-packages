#' Search the nearest neighbor of the design Xm in the full data X_full
#'
#' @param X_full an N*d real matrix. Covariates matrix.
#' @param Xm an n*d real matrix. Minimax design.
#'
#' @return an N*1 Boolean vector. Indiactor vector of the selected points.
#' @export
#'
#' @import nabor
#'
#' @examples
#' library(scales)
#' N = 200
#' d = 2
#' n = 20
#' M2 = 1
#' sigma2 = 20
#' const = matrix(rep(1,N),ncol=1)
#' X0 = matrix(rnorm(N*d),ncol=d)
#' X <-apply(X0,2,rescale)
#' Xm <- mMDesign_IPW(n,d)
#' idx_ipw <- NNS(X,Xm)
#' plot(X, main="MDS-OLS")
#' points(X[idx_ipw,], col="red", cex=2)
NNS <- function(X_full,Xm)
{
  n <- nrow(Xm)
  d <- ncol(Xm)

  NN <- knn(X_full,Xm,k=n,searchtype = 2L)$nn.idx
  idx <- c()
  for (i in 1:n)
  {
    if(!(NN[i,1]%in%idx))
    {
      idx<-c(idx,NN[i,1])
    }else{
      idx<-c(idx,NN[i,min(which(!(NN[i,] %in% idx)))])
    }
  }
  return(idx)
}
