#' Generating random minimax designs for the IPW estimator
#'
#' @param n a positive integer. Sample size.
#' @param d a positive integer. Dimension.
#' @param psqrt a functional variable. psqrt(x)=sqrt{1+z(x)^Tz(x)}
#'  with the default value z(x)=(1,2sqrt{3}(x_1-1/2),cdots,2sqrt{3}(x_d-1/2)).
#' @param C a positive real number. The maximum of the function psqrt
#' with the default value calculating by MC approximation.
#'
#' @return an n-point random minimax design for the IPW estimaotr.
#' @export
#'
#'
#' @examples
#' ## e.g.1 An example of 20-point 2-dimensional random minimax design
#' n = 20
#' d = 2
#' Xm = mMDesign_IPW(n,d)
#' PPlot(Xm)
mMDesign_IPW <- function(n,d,psqrt=NULL,C=NULL)
{
  if(is.null(psqrt)){
  psqrt<-function(x){
    p = sqrt(1+12*apply((x-0.5)^2,1,sum))
    return(p)
  }
  }

  if(is.null(C)){
  nlhd = 1000*d
  xlhd = randomLHS(nlhd,d)
  ylhd = psqrt(xlhd)
  C = max(ylhd)
  }

  samplingsqrt<-function(n,d){
    X = matrix(0,nrow = n,ncol = d)
    i = 1
    s = 1
    while (i<=n) {
      u = runif(1)
      U = matrix(runif(d),ncol=d)
      if(psqrt(U)>=u*C){
        X[i,] = U
        i = i + 1
      }else{}
      s = s + 1
    }
    return(X)
  }
  Xm = samplingsqrt(n,d)
  return(Xm)
}
